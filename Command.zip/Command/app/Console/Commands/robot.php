<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

        
class robot extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'robot {X} {Y} {DIR} {PATH} ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command to run robot';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $x = $this->argument('X');
        $y = $this->argument('Y');
        $dir = strtoupper($this->argument('DIR'));
        $path = strtoupper($this->argument('PATH'));

        $directionNumber = ["NORTH"=>"1", "EAST"=>'2',"SOUTH"=>"3", "WEST"=>"4"];  //here direction is key 
        
        $direction = [1=>"NORTH", 2=>"EAST",3=>"SOUTH", 4=>"WEST"];  //here number is the key
 
        $multiplier = [1=>1,2=>1,3=>-1,4=>-1];

        if(!is_numeric($x) || !is_numeric($y)){
            die("\nCo-ordinates must be Integer\n");
        }
        if($dir != 'NORTH' && $dir != 'EAST' && $dir != 'SOUTH' && $dir != 'WEST'){
            die("\nWrong Direction\n");
       }
       
        $dirNumber = $directionNumber[$dir];

       for($i = 0; $i < strlen($path); $i++ ){
            switch(strtoupper($path[$i])){
                case 'R':
                    if($dirNumber == 4){
                        $dirNumber = 1;
                    } else {
                        $dirNumber++;
                    }
                    break;
                        case 'L':
                                if($dirNumber == 1){
                                        $dirNumber = 4;
                                } else {
                                        $dirNumber--;
                                }
                                break;
                        case 'W':
                    if( !($dirNumber % 2) ){
                        $x += ($path[$i+1] * $multiplier[$dirNumber]);
                    } else {
                        $y += ($path[$i+1] * $multiplier[$dirNumber]);
                    }
                    $i++;
                                break;
                default:
                    if(is_numeric($path[$i])){
                        echo "\nNumber should be associated with 'W' walk ranging from 0 - 9\n";
                    } else {
                        echo "\nProvided char '".$path[$i]."' is not valid\n";
                    }
                    break;
            }
        
        }
        echo $x." ".$y." ".$direction[$dirNumber]."\n";


        return 0;
    }
}
